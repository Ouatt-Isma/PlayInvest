<script setup>
const { data: quizzes } = await useFetch('http://localhost:8000/quizzes')
</script>

<template>
  <div>
    <h2>Quiz</h2>
    <ul>
      <li v-for="q in quizzes" :key="q.id">{{ q.question }}</li>
    </ul>
  </div>
</template>
