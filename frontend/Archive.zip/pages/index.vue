<!-- <template>
    <div>
      <HeroSection />
      <WhySection />
      <HowItWorks />
      <NewsSection />
    </div>
  </template>
  
  <script setup>
  import HeroSection from '@/components/HeroSection.vue'
  import WhySection from '@/components/WhySection.vue'
  import HowItWorks from '@/components/HowItWorks.vue'
  import NewsSection from '@/components/NewsSection.vue'
  </script>
   -->

   <template>
    <div class="min-h-screen bg-teal-700 text-white flex items-center justify-center text-4xl font-bold">
      🎉 Tailwind is finally working!
    </div>
  </template>
  
  