<template>
    <div>
      <h1>Assets Page</h1>
      <p>Coming soon...</p>
    </div>
  </template>
  
  <script setup>
  // You can add your logic here later
  </script>
  