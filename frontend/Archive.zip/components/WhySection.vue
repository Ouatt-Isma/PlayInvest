<template>
    <section class="bg-gray-50 py-16 text-center">
      <h2 class="text-3xl font-bold mb-10">Pourquoi PlayInvest ?</h2>
      <div class="flex flex-wrap justify-center gap-8 px-4">
        <div class="max-w-xs">
          <img src="/icons/quiz.png" class="mx-auto h-20 mb-4" />
          <p>Apprentissage Ludique : Quiz, compétitions, challenges.</p>
        </div>
        <div class="max-w-xs">
          <img src="/icons/portfolio.png" class="mx-auto h-20 mb-4" />
          <p>Portefeuille Fictif Global : Actions, obligations, crypto du monde entier</p>
        </div>
        <div class="max-w-xs">
          <img src="/icons/security.png" class="mx-auto h-20 mb-4" />
          <p>Sécurité et Formation : Sensibiliser, former, engager progressivement.</p>
        </div>
      </div>
    </section>
  </template>
  