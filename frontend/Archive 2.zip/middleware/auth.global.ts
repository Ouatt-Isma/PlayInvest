// middleware/auth.global.ts
export default defineNuxtRouteMiddleware((to, from) => {
  const user = useCookie('user') // or useState('user') if you're storing it there

  // If the user is logged in and on an authenticated page...
  if (user.value && !to.meta.layout) {
    to.meta.layout = 'connected'
  }
})
