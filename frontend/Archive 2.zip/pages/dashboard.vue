<script setup>
import ActifFilters from '~/components/ActifFilters.vue'
import AssetsTable from '~/components/AssetsTable.vue'
definePageMeta({
  middleware: 'auth'
})
</script>

<template>
  <div>
    <ActifFilters/>
    <AssetsTable />
    <!-- Your Actifs Page Content -->
  </div>
</template>


