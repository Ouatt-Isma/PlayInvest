<template>
    <div>
      <Hero />
      <TrustedLogos />
      <WhyPlayInvest />
      <VirtualInvestment />
      <HowItWorks />
      <Stats />
      <News />
    </div>
  </template>
  
  <script setup>
  import Hero from '@/components/Hero.vue'
  import TrustedLogos from '@/components/TrustedLogos.vue'
  import WhyPlayInvest from '@/components/WhyPlayInvest.vue'
  import VirtualInvestment from '@/components/VirtualInvestment.vue'
  import HowItWorks from '@/components/HowItWorks.vue'
  import Stats from '@/components/Stats.vue'
  import News from '@/components/News.vue'
  </script>