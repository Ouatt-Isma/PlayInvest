
<template>
  <div>
    <!-- Hero Section -->
    <ActifsHero />
    <ActifFilters />
    <!-- Asset Table Section -->
    <AssetTable />
  </div>
</template>

<script setup>
import ActifsHero from '~/components/ActifsHero.vue'
import AssetTable from '~/components/AssetsTable.vue'
import ActifFilters from '~/components/ActifFilters.vue'
</script>
