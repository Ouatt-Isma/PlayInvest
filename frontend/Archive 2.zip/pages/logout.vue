<script setup lang="ts">
import { useCookie } from 'nuxt/app'
import { useRouter } from 'vue-router'

const router = useRouter()
const userCookie = useCookie('user', { path: '/' })

userCookie.value = null // Clear the cookie

router.push('/login') // Redirect to login
</script>

<template>
  <div>Déconnexion en cours...</div>
</template>
