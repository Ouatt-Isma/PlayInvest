<template>
  <section class="bg-white py-20">
    <div class="max-w-7xl mx-auto px-4 md:px-8 flex flex-col-reverse md:flex-row items-center gap-12">
      <!-- Text Section -->
      <div>
        <h2 class="text-4xl font-bold text-[#121212] mb-10 leading-snug">
          Challengez les meilleurs <br />
          PlayInvestisseurs
        </h2>
        <ul class="space-y-6">
          <li class="flex items-start gap-4">
            <img src="/icons/check-blue.png" class="w-6 h-6 mt-1 text-primary" alt="" />
            <div>
              <h3 class="font-semibold text-lg">Défis globaux</h3>
              <p class="text-gray-500">
                Affrontez d'autres investisseurs du monde entier dans des challenges passionnants.
              </p>
            </div>
          </li>
          <li class="flex items-start gap-4">
            <img src="/icons/check-blue.png" class="w-6 h-6 mt-1 text-primary" alt="" />
            <div>
              <h3 class="font-semibold text-lg">Gagnez des récompenses</h3>
              <p class="text-gray-500">
                Débloquez des fonds fictifs pour investir dans une large gamme d'actifs mondiaux.
              </p>
            </div>
          </li>
          <li class="flex items-start gap-4">
            <img src="/icons/check-blue.png" class="w-6 h-6 mt-1 text-primary" alt="" />
            <div>
              <h3 class="font-semibold text-lg">Classement en temps réel</h3>
              <p class="text-gray-500">
                Suivez les meilleurs joueurs à l’échelle mondiale, par pays et par catégorie d'actifs.
              </p>
            </div>
          </li>
          <li class="flex items-start gap-4">
            <img src="/icons/check-blue.png" class="w-6 h-6 mt-1 text-primary" alt="" />
            <div>
              <h3 class="font-semibold text-lg">Messagerie de motivation</h3>
              <p class="text-gray-500">
                Recevez des encouragements et des récompenses à chaque étape.
              </p>
            </div>
          </li>
        </ul>
      </div>

      <!-- Image Section -->
      <div class="flex justify-center">
        <img src="/images/image Q5.png" alt="Quiz Challenge" class="w-full max-w-md lg:max-w-[400px] xl:max-w-[440px]" />
      </div>
    </div>
  </section>
</template>
