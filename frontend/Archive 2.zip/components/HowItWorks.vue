<template>
    <section class="py-20 bg-white">
      <div class="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <img src="/images/content.png" class="rounded-lg shadow-md" />
        <div>
          <h2 class="text-3xl font-bold mb-6">Comment Investir sur PlayInvest</h2>
          <ol class="list-decimal list-inside space-y-2 text-left text-gray-700">
            <li>Créez votre compte</li>
            <li>Explorez les actifs</li>
            <li>Investissez des fonds fictifs</li>
            <li>Suivez votre performance</li>
            <li>Participez aux quiz et challenges</li>
          </ol>
          <NuxtLink to="/register" class="inline-block mt-6 bg-teal-900 text-white py-2 px-4 rounded hover:bg-teal-800">Commencer</NuxtLink>
        </div>
      </div>
    </section>
  </template>
  