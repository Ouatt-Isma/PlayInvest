<template>
  <section class="max-w-7xl mx-auto px-4 md:px-8 flex flex-col-reverse md:flex-row items-center gap-12 bg-gray-50 ">
    <!-- Left: Visual & Avatars -->
    <div class="w-full md:w-1/2 relative mb-12 md:mb-0">
      <!-- <div class="max-w-7xl mx-auto px-4 md:px-8 flex flex-col-reverse md:flex-row items-center gap-12"> -->
      <img src="/images/Image Q6.png" alt="Quiz Progress" class="w-full max-w-md mx-auto" />
    </div>
    <!-- Right: Text Content -->
    <div class="w-full md:w-1/2 max-w-xl text-left">
      <h2 class="text-4xl font-bold mb-6 leading-tight">Suivi de vos progrès et<br />performances</h2>
      <p class="text-gray-600 mb-4">
        Suivez l’évolution de vos compétences et performances au fur et à mesure que vous participez aux quiz et défis.
      </p>
      <p class="text-gray-600 mb-4">
        Visualisez vos résultats à travers des graphiques détaillés et comparez vos performances avec celles d'investisseurs du monde entier.
      </p>
      <p class="text-gray-600 mb-8">
        Accédez à un historique complet de vos quiz réussis, des fonds fictifs gagnés et des investissements virtuels effectués. Cela vous permet d'analyser vos progrès et de vous améliorer dans votre parcours d'investissement global.
      </p>
      <button class="bg-teal-800 text-white font-semibold px-6 py-3 rounded-lg hover:bg-teal-900 transition">Commencer</button>
    </div>
  </section>
</template>
