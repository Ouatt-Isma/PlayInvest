<template>
    <section class="bg-gray-50 py-16 text-center">
      <h2 class="text-3xl font-bold mb-10">Testez vos connaissances en investissement</h2>
      <div class="flex flex-wrap justify-center gap-8 px-4 ">
        <div class="max-w-xs m-4 border border-black rounded-xl p-4">
          <img src="/images/image Q.png" alt="Apprenez en jouant" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Apprenez en jouant</h3>
        <p class="text-gray-500 text-sm">Participez à des quiz interactifs sur des actifs mondiaux.</p>
        </div>
        <div class="max-w-xs m-4 border border-black rounded-xl p-4">
          <img src="/images/image Q2.png" alt="Récompenses immédiates" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Récompenses immédiates</h3>
        <p class="text-gray-500 text-sm">Gagnez des fonds fictifs pour investir dans des actifs à l’échelle mondiale.</p>
        </div>
        <div class="max-w-xs m-4 border border-black rounded-xl p-4">
          <img src="/images/image Q3.png" alt="Niveaux adaptés" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Niveaux adaptés</h3>
        <p class="text-gray-500 text-sm">Testez vos connaissances sur divers marchés mondiaux (Afrique, Europe, Asie, etc.).</p>
        </div>
      </div>
    </section>
  </template>
  




<!-- <template>
  <section class="py-16 px-6 text-center bg-white">
    <h2 class="text-4xl font-bold mb-12">Testez vos connaissances en investissement</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 justify-items-center">
      <div class="bg-white rounded-xl shadow-md p-8 max-w-xs">
        <img src="/images/image Q.png" alt="Apprenez en jouant" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Apprenez en jouant</h3>
        <p class="text-gray-500 text-sm">Participez à des quiz interactifs sur des actifs mondiaux.</p>
      </div>
      <div class="bg-white rounded-xl shadow-md p-8 max-w-xs">
        <img src="/images/image Q2.png" alt="Récompenses immédiates" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Récompenses immédiates</h3>
        <p class="text-gray-500 text-sm">Gagnez des fonds fictifs pour investir dans des actifs à l’échelle mondiale.</p>
      </div>
      <div class="bg-white rounded-xl shadow-md p-8 max-w-xs">
        <img src="/images/image Q3.png" alt="Niveaux adaptés" class="w-20 h-20 mx-auto mb-4" />
        <h3 class="text-xl font-semibold mb-2">Niveaux adaptés</h3>
        <p class="text-gray-500 text-sm">Testez vos connaissances sur divers marchés mondiaux (Afrique, Europe, Asie, etc.).</p>
      </div>
    </div>
  </section>
</template> -->
