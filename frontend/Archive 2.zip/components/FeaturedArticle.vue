<template>
  <div class="w-full bg-white shadow-md rounded-xl overflow-hidden">
    <img
      src="/images/B1.jpg"
      alt="Carte investissement"
      class="w-full h-auto object-cover block"
    />

    <div class="p-4">
      <h3 class="text-xl font-semibold mb-2">
        Comment débuter dans l’investissement sans risque
      </h3>
      <p class="text-sm text-gray-600">
        9/5/2025 &nbsp; • &nbsp; Rédigé par John Doe
      </p>
    </div>
  </div>
</template>
