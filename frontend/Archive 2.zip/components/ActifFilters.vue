<template>
  <div class="p-6 bg-white rounded-xl shadow-md w-full max-w-full">
    <div class="flex flex-wrap items-center gap-4 mb-6">
      <!-- Search bar -->
      <div class="flex items-center px-4 py-3 border border-gray-300 rounded-xl w-full max-w-md bg-white">
        <input
          type="text"
          placeholder="Rechercher un actif"
          class="flex-1 text-gray-600 focus:outline-none"
        />
        <MagnifyingGlassIcon class="w-5 h-5 text-gray-500" />
      </div>

      <!-- Dropdowns -->
      <select class="px-4 py-3 border border-gray-300 rounded-xl bg-white text-gray-700">
        <option disabled selected>Catégorie d'Actif</option>
        <option>Actions</option>
        <option>Crypto</option>
      </select>

      <select class="px-4 py-3 border border-gray-300 rounded-xl bg-white text-gray-700">
        <option disabled selected>Région</option>
        <option>Afrique</option>
        <option>USA</option>
      </select>

      <select class="px-4 py-3 border border-gray-300 rounded-xl bg-white text-gray-700">
        <option disabled selected>Performance</option>
        <option>Meilleure Performance</option>
        <option>Moins bonne Performance</option>
      </select>
    </div>

    <!-- Region Tabs -->
    <div class="flex flex-wrap gap-4">
      <button class="bg-teal-700 text-white font-medium px-4 py-2 rounded-lg">
        Toutes les actions de la BRVM
      </button>
      <button class="text-gray-700 hover:underline">Afrique</button>
      <button class="text-gray-700 hover:underline">Europe</button>
      <button class="text-gray-700 hover:underline">USA</button>
      <button class="text-gray-700 hover:underline">Monde</button>
      <button class="text-gray-700 hover:underline">cryptos</button>
      <button class="text-gray-700 hover:underline">ETF</button>
      <button class="text-gray-700 hover:underline">Autres</button>
    </div>
  </div>
</template>

<script setup>
import { MagnifyingGlassIcon } from '@heroicons/vue/24/solid'
</script>
