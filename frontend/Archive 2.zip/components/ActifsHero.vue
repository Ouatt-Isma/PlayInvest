<template>
  <section class="flex flex-col md:flex-row items-center justify-between px-10 py-20 bg-[#f7f8fc]">
    <div class="md:w-1/2 mb-10 md:mb-0">
      <h1 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
        Investir dans les Actifs Mondiaux
      </h1>
      <p class="text-gray-600 mb-6">
        Explorez les meilleures opportunités d’investissement sur le continent africain avec PlayInvest.
      </p>
      <NuxtLink to="/plateforme" class="bg-[#0D5254] text-white px-6 py-3 rounded-md font-semibold">
        Découvrir la Plateforme
      </NuxtLink>
    </div>
    <div class="md:w-1/2">
      <img src="/images/Header actifs.png" alt="Actifs illustration" class="w-full max-w-md mx-auto" />
    </div>
  </section>
</template>
