<template>
  <section class="px-10 py-12 bg-gradient-to-br from-white to-[#e6f6f8]">

    <!-- Table -->
    <table class="w-full bg-white rounded shadow overflow-hidden">
      <thead>
        <tr class="text-left bg-gray-100">
          <th class="p-4">#</th>
          <th class="p-4">Nom</th>
          <th class="p-4">Prix</th>
          <th class="p-4">7 jours %</th>
          <th class="p-4">Graphique</th>
          <th class="p-4">Fiche descriptive</th>
          <th class="p-4">Trade</th>
        </tr>
      </thead>
      <tbody>
        <!-- Repeat with v-for -->
        <tr>
          <td class="p-4">1</td>
          <td class="p-4 flex items-center gap-2">
            <img src="/logos/facebook.webp" class="w-6" />
            Meta Platforms
          </td>
          <td class="p-4">$347.68</td>
          <td class="p-4 text-green-600 font-medium">+1.71%</td>
          <td class="p-4">
            <img src="/plots/ex1.png" class="h-6" />
          </td>
          <td class="p-4">
            <NuxtLink to="/fiche/meta">
              <img src="/icons/file-icon.svg" class="w-4" />
            </NuxtLink>
          </td>
          <td class="p-4">
            <button class="border px-3 py-1 rounded">Trade</button>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
